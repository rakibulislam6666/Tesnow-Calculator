package com.tesnow.calculator;

import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
import android.view.*;
import android.widget.*;

public class AboutActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeUtils.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        ImageButton btnBack = findViewById(R.id.btnBack);
       
		btnBack.setOnClickListener(
            new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    finish();
                }
            }
        );

        LinearLayout btnFacebook = findViewById(R.id.btnFacebook);
        LinearLayout btnYoutube = findViewById(R.id.btnYoutube);
        LinearLayout btnTiktok = findViewById(R.id.btnTiktok);

        btnFacebook.setOnClickListener(
            new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    openLink(getString(R.string.facebook_link));
                }
            }
        );
		
		
		
        btnYoutube.setOnClickListener(
            new View.OnClickListener() {

                @Override
                public void onClick(View v) {
					openLink(getString(R.string.youtube_link));
                }
            }
        );
		
		
        btnTiktok.setOnClickListener(
            new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    openLink(getString(R.string.tiktok_link));
                }
            }
        );
		
		
	
    }

    private void openLink(String url) {
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, R.string.no_app_found, Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.no_app_found, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, R.string.no_app_found, Toast.LENGTH_SHORT).show();
        }
    }
}
