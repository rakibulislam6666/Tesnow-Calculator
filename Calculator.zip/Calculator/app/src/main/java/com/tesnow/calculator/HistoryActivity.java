package com.tesnow.calculator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HistoryActivity extends Activity
implements HistoryAdapter.Listener {

    public static final String EXTRA_SELECTED_EXPRESSION =
	"selected_expression";

    private RecyclerView recyclerView;
    private TextView tvEmptyState;
    private HistoryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ThemeUtils.applyTheme(this);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_history);

        ImageButton btnBack =
			(ImageButton) findViewById(R.id.btnBack);

        ImageButton btnClearAll =
			(ImageButton) findViewById(R.id.btnClearAll);

        recyclerView =
			(RecyclerView) findViewById(R.id.recyclerHistory);

        tvEmptyState =
			(TextView) findViewById(R.id.tvEmptyState);

        /* Back button */
        if (btnBack != null) {
            btnBack.setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						finish();
					}
				}
            );
        }

        /* Clear All button */
        if (btnClearAll != null) {
            btnClearAll.setOnClickListener(
				new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						showClearAllDialog();
					}
				}
            );
        }

        /* RecyclerView */
        if (recyclerView != null) {

            recyclerView.setLayoutManager(
				new LinearLayoutManager(this)
            );

            List<HistoryItem> entries =
				HistoryManager.getEntries(this);

            adapter =
				new HistoryAdapter(entries, this);

            recyclerView.setAdapter(adapter);

            updateEmptyState(entries.isEmpty());

        } else {

            if (tvEmptyState != null) {
                tvEmptyState.setVisibility(View.VISIBLE);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (adapter != null) {
            refreshList();
        }
    }

    /* Refresh history list */
    private void refreshList() {

        if (adapter == null) {
            return;
        }

        List<HistoryItem> entries =
			HistoryManager.getEntries(this);

        adapter.setItems(entries);

        updateEmptyState(entries.isEmpty());
    }

    /* Empty state */
    private void updateEmptyState(boolean isEmpty) {

        if (tvEmptyState != null) {

            if (isEmpty) {
                tvEmptyState.setVisibility(View.VISIBLE);
            } else {
                tvEmptyState.setVisibility(View.GONE);
            }
        }

        if (recyclerView != null) {

            if (isEmpty) {
                recyclerView.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
            }
        }
    }

    /* Clear all confirmation dialog */
    private void showClearAllDialog() {

        if (adapter == null) {
            return;
        }

        if (adapter.getItemCount() == 0) {

            Toast.makeText(
				this,
				R.string.history_cleared_toast,
				Toast.LENGTH_SHORT
            ).show();

            return;
        }

        AlertDialog.Builder builder =
			new AlertDialog.Builder(this);

        builder.setTitle(
			R.string.clear_history_title
        );

        builder.setMessage(
			R.string.clear_history_message
        );

        builder.setNegativeButton(
			R.string.action_cancel,
			new DialogInterface.OnClickListener() {

				@Override
				public void onClick(
					DialogInterface dialog,
					int which) {

					dialog.dismiss();
				}
			}
        );

        builder.setPositiveButton(
			R.string.action_clear,
			new DialogInterface.OnClickListener() {

				@Override
				public void onClick(
					DialogInterface dialog,
					int which) {

					try {

						HistoryManager.clearAll(
							HistoryActivity.this
						);

						refreshList();

						Toast.makeText(
							HistoryActivity.this,
							R.string.history_cleared_toast,
							Toast.LENGTH_SHORT
						).show();

					} catch (Exception e) {

						Toast.makeText(
							HistoryActivity.this,
							"Could not clear history",
							Toast.LENGTH_SHORT
						).show();
					}

					dialog.dismiss();
				}
			}
        );

        builder.setCancelable(true);

        builder.show();
    }

    /* History item click */
    @Override
    public void onItemClick(HistoryItem item) {

        if (item == null) {
            return;
        }

        String result = item.getResult();

        if (result == null) {
            return;
        }

        Intent resultIntent =
			new Intent();

        resultIntent.putExtra(
			EXTRA_SELECTED_EXPRESSION,
			result
        );

        setResult(
			Activity.RESULT_OK,
			resultIntent
        );

        finish();
    }

    /* History item long press */
    @Override
    public void onItemLongClick(
		final int position,
		final HistoryItem item) {

        if (adapter == null) {
            return;
        }

        if (position < 0 ||
			position >= adapter.getItemCount()) {
            return;
        }

        AlertDialog.Builder builder =
			new AlertDialog.Builder(this);

        builder.setTitle(
			R.string.delete_entry_title
        );

        builder.setMessage(
			R.string.delete_entry_message
        );

        builder.setNegativeButton(
			R.string.action_cancel,
			new DialogInterface.OnClickListener() {

				@Override
				public void onClick(
					DialogInterface dialog,
					int which) {

					dialog.dismiss();
				}
			}
        );

        builder.setPositiveButton(
			R.string.action_clear,
			new DialogInterface.OnClickListener() {

				@Override
				public void onClick(
					DialogInterface dialog,
					int which) {

					if (adapter == null) {
						dialog.dismiss();
						return;
					}

					int count =
						adapter.getItemCount();

					if (position < 0 ||
						position >= count) {

						dialog.dismiss();
						return;
					}

					try {

						HistoryManager.deleteEntryAt(
							HistoryActivity.this,
							position
						);

						refreshList();

					} catch (Exception e) {

						Toast.makeText(
							HistoryActivity.this,
							"Could not delete history",
							Toast.LENGTH_SHORT
						).show();
					}

					dialog.dismiss();
				}
			}
        );

        builder.setCancelable(true);

        builder.show();
    }
}
