package com.tesnow.calculator;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class ThemeUtils {

    public static final String PREFS_NAME = "tesnow_calculator_prefs";
    public static final String KEY_THEME_MODE = "theme_mode";
    public static final String THEME_LIGHT = "light";
    public static final String THEME_DARK = "dark";

    public static String getSavedTheme(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_THEME_MODE, THEME_LIGHT);
    }

    public static void saveTheme(Context context, String themeMode) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_THEME_MODE, themeMode);
        editor.apply();
    }

    public static void applyTheme(Activity activity) {
        String theme = getSavedTheme(activity);
        if (THEME_DARK.equals(theme)) {
            activity.setTheme(R.style.AppTheme_Dark);
        } else {
            activity.setTheme(R.style.AppTheme_Light);
        }
    }
}