package com.tesnow.calculator;

public class HistoryItem {

    private final String expression;
    private final String result;
    private final long timestampMillis;

    public HistoryItem(String expression, String result, long timestampMillis) {
        this.expression = expression;
        this.result = result;
        this.timestampMillis = timestampMillis;
    }

    public String getExpression() {
        return expression;
    }

    public String getResult() {
        return result;
    }

    public long getTimestampMillis() {
        return timestampMillis;
    }
}
