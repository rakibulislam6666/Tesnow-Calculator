package com.tesnow.calculator;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Stores calculation history as a JSON array inside SharedPreferences.
 * Entries are capped at MAX_ENTRIES (oldest entries are dropped first).
 */
public class HistoryManager {

    private static final String PREFS_NAME = ThemeUtils.PREFS_NAME;
    private static final String KEY_HISTORY = "history_entries";
    private static final int MAX_ENTRIES = 200;

    private static final String FIELD_EXPRESSION = "expression";
    private static final String FIELD_RESULT = "result";
    private static final String FIELD_TIMESTAMP = "timestamp";

    /** Adds a new entry at the end of storage (oldest-to-newest order internally). */
    public static void addEntry(Context context, String expression, String result) {
        try {
            JSONArray array = readRawArray(context);

            JSONObject obj = new JSONObject();
            obj.put(FIELD_EXPRESSION, expression);
            obj.put(FIELD_RESULT, result);
            obj.put(FIELD_TIMESTAMP, System.currentTimeMillis());

            array.put(obj);

            while (array.length() > MAX_ENTRIES) {
                array.remove(0);
            }

            writeRawArray(context, array);
        } catch (Exception ignored) {
            // Never let history saving crash the calculator.
        }
    }

    /** Returns entries newest-first. */
    public static List<HistoryItem> getEntries(Context context) {
        List<HistoryItem> result = new ArrayList<>();
        try {
            JSONArray array = readRawArray(context);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;
                String expression = obj.optString(FIELD_EXPRESSION, "");
                String value = obj.optString(FIELD_RESULT, "");
                long timestamp = obj.optLong(FIELD_TIMESTAMP, 0L);
                result.add(new HistoryItem(expression, value, timestamp));
            }
        } catch (Exception ignored) {
            // Return whatever was successfully parsed.
        }
        Collections.reverse(result);
        return result;
    }

    /**
     * Deletes the entry at the given position, where position matches the
     * newest-first order returned by getEntries().
     */
    public static void deleteEntryAt(Context context, int newestFirstIndex) {
        try {
            JSONArray array = readRawArray(context);
            int rawIndex = array.length() - 1 - newestFirstIndex;
            if (rawIndex < 0 || rawIndex >= array.length()) {
                return;
            }
            JSONArray rebuilt = new JSONArray();
            for (int i = 0; i < array.length(); i++) {
                if (i != rawIndex) {
                    rebuilt.put(array.get(i));
                }
            }
            writeRawArray(context, rebuilt);
        } catch (Exception ignored) {
        }
    }

    public static void clearAll(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_HISTORY).apply();
    }

    private static JSONArray readRawArray(Context context) throws JSONException {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String json = prefs.getString(KEY_HISTORY, "[]");
        return new JSONArray(json);
    }

    private static void writeRawArray(Context context, JSONArray array) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_HISTORY, array.toString()).apply();
    }
}
