package com.tesnow.calculator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {

    private boolean initializing = true;

    private PreferenceManager preferenceManager;

    private TextView tvDecimalPlacesValue;

    private static final String[] DECIMAL_LABELS = {
            "Auto",
            "0",
            "1",
            "2",
            "3",
            "4"
    };

    private static final String[] DECIMAL_VALUES = {
            PreferenceManager.DECIMAL_AUTO,
            "0",
            "1",
            "2",
            "3",
            "4"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ThemeUtils.applyTheme(this);

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_settings);

        preferenceManager =
                new PreferenceManager(this);

        ImageButton btnBack =
                (ImageButton) findViewById(R.id.btnBack);

        if (btnBack != null) {

            btnBack.setOnClickListener(
                    new android.view.View.OnClickListener() {

                        @Override
                        public void onClick(
                                android.view.View v) {

                            finish();
                        }
                    }
            );
        }

        setupThemeSection();

        setupDecimalPlacesRow();

        setupSwitches();

        /*
         * Clear History removed.
         */

        initializing = false;
    }

    private void setupThemeSection() {

        RadioGroup rgTheme =
                (RadioGroup) findViewById(R.id.rgTheme);

        RadioButton rbLight =
                (RadioButton) findViewById(R.id.rbLight);

        RadioButton rbDark =
                (RadioButton) findViewById(R.id.rbDark);

        if (rgTheme == null ||
                rbLight == null ||
                rbDark == null) {
            return;
        }

        String current =
                ThemeUtils.getSavedTheme(this);

        if (ThemeUtils.THEME_DARK.equals(current)) {

            rbDark.setChecked(true);

        } else {

            rbLight.setChecked(true);
        }

        rgTheme.setOnCheckedChangeListener(
                new RadioGroup.OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(
                            RadioGroup group,
                            int checkedId) {

                        if (initializing) {
                            return;
                        }

                        String selected;

                        if (checkedId == R.id.rbDark) {

                            selected =
                                    ThemeUtils.THEME_DARK;

                        } else {

                            selected =
                                    ThemeUtils.THEME_LIGHT;
                        }

                        String previous =
                                ThemeUtils.getSavedTheme(
                                        SettingsActivity.this
                                );

                        if (!selected.equals(previous)) {

                            ThemeUtils.saveTheme(
                                    SettingsActivity.this,
                                    selected
                            );

                            recreate();
                        }
                    }
                }
        );
    }

    private void setupDecimalPlacesRow() {

        tvDecimalPlacesValue =
                (TextView) findViewById(
                        R.id.tvDecimalPlacesValue
                );

        LinearLayout rowDecimalPlaces =
                (LinearLayout) findViewById(
                        R.id.rowDecimalPlaces
                );

        if (tvDecimalPlacesValue == null ||
                rowDecimalPlaces == null) {
            return;
        }

        updateDecimalPlacesLabel();

        rowDecimalPlaces.setOnClickListener(
                new android.view.View.OnClickListener() {

                    @Override
                    public void onClick(
                            android.view.View v) {

                        showDecimalPlacesDialog();
                    }
                }
        );
    }

    private void updateDecimalPlacesLabel() {

        if (tvDecimalPlacesValue == null) {
            return;
        }

        String current =
                preferenceManager.getDecimalPlaces();

        for (int i = 0;
             i < DECIMAL_VALUES.length;
             i++) {

            if (DECIMAL_VALUES[i].equals(current)) {

                tvDecimalPlacesValue.setText(
                        DECIMAL_LABELS[i]
                );

                return;
            }
        }

        tvDecimalPlacesValue.setText(
                DECIMAL_LABELS[0]
        );
    }

    private void showDecimalPlacesDialog() {

        String current =
                preferenceManager.getDecimalPlaces();

        int checkedIndex = 0;

        for (int i = 0;
             i < DECIMAL_VALUES.length;
             i++) {

            if (DECIMAL_VALUES[i].equals(current)) {

                checkedIndex = i;

                break;
            }
        }

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle(
                R.string.setting_decimal_places
        );

        builder.setSingleChoiceItems(
                DECIMAL_LABELS,
                checkedIndex,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(
                            DialogInterface dialog,
                            int which) {

                        if (which >= 0 &&
                                which < DECIMAL_VALUES.length) {

                            preferenceManager.setDecimalPlaces(
                                    DECIMAL_VALUES[which]
                            );

                            updateDecimalPlacesLabel();
                        }

                        dialog.dismiss();
                    }
                }
        );

        builder.setNegativeButton(
                R.string.action_cancel,
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(
                            DialogInterface dialog,
                            int which) {

                        dialog.dismiss();
                    }
                }
        );

        builder.show();
    }

    private void setupSwitches() {

        Switch switchThousandsSeparator =
                (Switch) findViewById(
                        R.id.switchThousandsSeparator
                );

        Switch switchShowExpression =
                (Switch) findViewById(
                        R.id.switchShowExpression
                );

        Switch switchButtonSound =
                (Switch) findViewById(
                        R.id.switchButtonSound
                );

        Switch switchVibration =
                (Switch) findViewById(
                        R.id.switchVibration
                );

        Switch switchKeepScreenOn =
                (Switch) findViewById(
                        R.id.switchKeepScreenOn
                );

        Switch switchSaveHistory =
                (Switch) findViewById(
                        R.id.switchSaveHistory
                );

        if (switchThousandsSeparator != null) {

            switchThousandsSeparator.setChecked(
                    preferenceManager
                            .isThousandsSeparatorEnabled()
            );

            switchThousandsSeparator
                    .setOnCheckedChangeListener(
                            new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(
                                        CompoundButton buttonView,
                                        boolean isChecked) {

                                    preferenceManager
                                            .setThousandsSeparatorEnabled(
                                                    isChecked
                                            );
                                }
                            }
                    );
        }

        if (switchShowExpression != null) {

            switchShowExpression.setChecked(
                    preferenceManager
                            .isShowExpressionEnabled()
            );

            switchShowExpression
                    .setOnCheckedChangeListener(
                            new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(
                                        CompoundButton buttonView,
                                        boolean isChecked) {

                                    preferenceManager
                                            .setShowExpressionEnabled(
                                                    isChecked
                                            );
                                }
                            }
                    );
        }

        if (switchButtonSound != null) {

            switchButtonSound.setChecked(
                    preferenceManager
                            .isButtonSoundEnabled()
            );

            switchButtonSound
                    .setOnCheckedChangeListener(
                            new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(
                                        CompoundButton buttonView,
                                        boolean isChecked) {

                                    preferenceManager
                                            .setButtonSoundEnabled(
                                                    isChecked
                                            );
                                }
                            }
                    );
        }

        if (switchVibration != null) {

            switchVibration.setChecked(
                    preferenceManager
                            .isVibrationEnabled()
            );

            switchVibration
                    .setOnCheckedChangeListener(
                            new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(
                                        CompoundButton buttonView,
                                        boolean isChecked) {

                                    preferenceManager
                                            .setVibrationEnabled(
                                                    isChecked
                                            );
                                }
                            }
                    );
        }

        if (switchKeepScreenOn != null) {

            switchKeepScreenOn.setChecked(
                    preferenceManager
                            .isKeepScreenOnEnabled()
            );

            switchKeepScreenOn
                    .setOnCheckedChangeListener(
                            new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(
                                        CompoundButton buttonView,
                                        boolean isChecked) {

                                    preferenceManager
                                            .setKeepScreenOnEnabled(
                                                    isChecked
                                            );
                                }
                            }
                    );
        }

        if (switchSaveHistory != null) {

            switchSaveHistory.setChecked(
                    preferenceManager
                            .isSaveHistoryEnabled()
            );

            switchSaveHistory
                    .setOnCheckedChangeListener(
                            new CompoundButton.OnCheckedChangeListener() {

                                @Override
                                public void onCheckedChanged(
                                        CompoundButton buttonView,
                                        boolean isChecked) {

                                    preferenceManager
                                            .setSaveHistoryEnabled(
                                                    isChecked
                                            );
                                }
                            }
                    );
        }
    }
}