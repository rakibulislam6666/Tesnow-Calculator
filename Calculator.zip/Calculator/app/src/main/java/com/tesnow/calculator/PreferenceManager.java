package com.tesnow.calculator;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Central place for all app settings (except theme, which stays in ThemeUtils
 * for backward compatibility). Uses the same SharedPreferences file.
 */
public class PreferenceManager {

    private static final String PREFS_NAME = ThemeUtils.PREFS_NAME;

    private static final String KEY_DECIMAL_PLACES = "decimal_places";      // "auto","0","1","2","3","4"
    private static final String KEY_THOUSANDS_SEPARATOR = "thousands_separator";
    private static final String KEY_SHOW_EXPRESSION = "show_expression";
    private static final String KEY_BUTTON_SOUND = "button_sound";
    private static final String KEY_VIBRATION = "vibration";
    private static final String KEY_KEEP_SCREEN_ON = "keep_screen_on";
    private static final String KEY_SAVE_HISTORY = "save_history"; // reserved for future history feature

    public static final String DECIMAL_AUTO = "auto";

    private final SharedPreferences prefs;

    public PreferenceManager(Context context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ---------- Decimal Places ----------
    public String getDecimalPlaces() {
        return prefs.getString(KEY_DECIMAL_PLACES, DECIMAL_AUTO);
    }

    public void setDecimalPlaces(String value) {
        prefs.edit().putString(KEY_DECIMAL_PLACES, value).apply();
    }

    // ---------- Thousands Separator ----------
    public boolean isThousandsSeparatorEnabled() {
        return prefs.getBoolean(KEY_THOUSANDS_SEPARATOR, true);
    }

    public void setThousandsSeparatorEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_THOUSANDS_SEPARATOR, enabled).apply();
    }

    // ---------- Show Expression ----------
    public boolean isShowExpressionEnabled() {
        return prefs.getBoolean(KEY_SHOW_EXPRESSION, true);
    }

    public void setShowExpressionEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_SHOW_EXPRESSION, enabled).apply();
    }

    // ---------- Button Sound ----------
    public boolean isButtonSoundEnabled() {
        return prefs.getBoolean(KEY_BUTTON_SOUND, true);
    }

    public void setButtonSoundEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_BUTTON_SOUND, enabled).apply();
    }

    // ---------- Vibration ----------
    public boolean isVibrationEnabled() {
        return prefs.getBoolean(KEY_VIBRATION, true);
    }

    public void setVibrationEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_VIBRATION, enabled).apply();
    }

    // ---------- Keep Screen On ----------
    public boolean isKeepScreenOnEnabled() {
        return prefs.getBoolean(KEY_KEEP_SCREEN_ON, false);
    }

    public void setKeepScreenOnEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_KEEP_SCREEN_ON, enabled).apply();
    }

    // ---------- Save History (UI ready, logic implemented later) ----------
    public boolean isSaveHistoryEnabled() {
        return prefs.getBoolean(KEY_SAVE_HISTORY, true);
    }

    public void setSaveHistoryEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_SAVE_HISTORY, enabled).apply();
    }

    /**
     * Placeholder for future history clearing logic.
     * Currently there is no stored history data, so this is a no-op.
     */
    public void clearHistoryData() {
        // TODO: implement when History feature is built
    }
}