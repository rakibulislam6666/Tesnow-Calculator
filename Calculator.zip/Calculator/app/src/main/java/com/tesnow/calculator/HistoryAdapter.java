package com.tesnow.calculator;

import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    public interface Listener {
        void onItemClick(HistoryItem item);
        void onItemLongClick(int position, HistoryItem item);
    }

    private final List<HistoryItem> items;
    private final Listener listener;

    public HistoryAdapter(List<HistoryItem> items, Listener listener) {
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
			.inflate(R.layout.item_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        final HistoryItem item = items.get(position);
        holder.tvExpression.setText(item.getExpression());
        holder.tvResult.setText("= " + item.getResult());
        holder.tvTimestamp.setText(
			DateFormat.format("dd MMM, hh:mm a", item.getTimestampMillis())
        );

        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					if (listener != null) {
						listener.onItemClick(item);
					}
				}
			});

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
				@Override
				public boolean onLongClick(View v) {
					if (listener != null) {
						int pos = holder.getAdapterPosition();
						if (pos != RecyclerView.NO_POSITION) {
							listener.onItemLongClick(pos, item);
						}
					}
					return true;
				}
			});
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void removeAt(int position) {
        if (position < 0 || position >= items.size()) return;
        items.remove(position);
        notifyItemRemoved(position);
    }

    public void setItems(List<HistoryItem> newItems) {
        items.clear();
        if (newItems != null) {
            items.addAll(newItems);
        }
        notifyDataSetChanged();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        final TextView tvExpression;
        final TextView tvResult;
        final TextView tvTimestamp;

        HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvExpression = itemView.findViewById(R.id.tvHistoryExpression);
            tvResult = itemView.findViewById(R.id.tvHistoryResult);
            tvTimestamp = itemView.findViewById(R.id.tvHistoryTimestamp);
        }
    }
}
