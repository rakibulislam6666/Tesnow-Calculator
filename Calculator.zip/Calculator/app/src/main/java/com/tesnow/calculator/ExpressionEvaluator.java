package com.tesnow.calculator;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * A safe recursive-descent expression evaluator.
 *
 * Supports:
 * +  -  *  /  %
 * parentheses
 * decimals
 * unary minus
 *
 * Auto result formatting:
 * - Maximum 15 significant digits
 * - Large/small values use scientific notation when appropriate
 */
public class ExpressionEvaluator {

    private static final int MAX_SIGNIFICANT_DIGITS = 15;

    public static double evaluate(String expression) {

        String sanitized = sanitize(expression);

        if (sanitized.isEmpty()) {
            throw new IllegalArgumentException("Empty expression");
        }

        Parser parser = new Parser(sanitized);

        double result = parser.parseExpression();

        parser.skipWhitespace();

        if (!parser.isAtEnd()) {
            throw new IllegalArgumentException("Invalid expression");
        }

        if (Double.isNaN(result) || Double.isInfinite(result)) {
            throw new ArithmeticException("Math error");
        }

        return result;
    }

    /**
     * Converts display symbols:
     *
     * × -> *
     * ÷ -> /
     * − -> -
     *
     * Removes dangling operators/dots
     * and closes unmatched parentheses.
     */
    public static String sanitize(String expression) {

        if (expression == null) {
            return "";
        }

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < expression.length(); i++) {

            char c = expression.charAt(i);

            switch (c) {

                case '\u00d7':
                    sb.append('*');
                    break;

                case '\u00f7':
                    sb.append('/');
                    break;

                case '\u2212':
                    sb.append('-');
                    break;

                default:
                    sb.append(c);
            }
        }

        String s = sb.toString();

        while (!s.isEmpty()
			   && "+-*/%.".indexOf(
				   s.charAt(s.length() - 1)
			   ) >= 0) {

            s = s.substring(0, s.length() - 1);
        }

        int openCount = 0;

        for (int i = 0; i < s.length(); i++) {

            char c = s.charAt(i);

            if (c == '(') {
                openCount++;
            } else if (c == ')') {
                openCount--;
            }
        }

        StringBuilder result =
			new StringBuilder(s);

        for (int i = 0; i < openCount; i++) {
            result.append(')');
        }

        return result.toString();
    }

    /**
     * Backward-compatible overload.
     *
     * Auto decimal places
     * No thousands separator
     */
    public static String formatResult(double value) {

        return formatResult(
			value,
			PreferenceManager.DECIMAL_AUTO,
			false
        );
    }

    /**
     * Formats calculator result.
     *
     * decimalPlacesPref:
     * "auto"
     * "0"
     * "1"
     * "2"
     * "3"
     * "4"
     *
     * Auto mode:
     * Maximum 15 significant digits.
     *
     * Large/small numbers are displayed using
     * scientific notation when appropriate.
     */
    public static String formatResult(
		double value,
		String decimalPlacesPref,
		boolean useThousandsSeparator) {

        if (Double.isNaN(value)
			|| Double.isInfinite(value)) {

            throw new ArithmeticException(
				"Math error"
            );
        }

        /*
         * Remove negative zero.
         */
        if (value == 0d) {
            return "0";
        }

        /*
         * AUTO MODE
         *
         * Maximum 15 significant digits.
         */
        if (decimalPlacesPref == null
			|| PreferenceManager.DECIMAL_AUTO.equals(
				decimalPlacesPref
			)) {

            return formatAuto(
				value,
				useThousandsSeparator
            );
        }

        /*
         * FIXED DECIMAL MODE
         */
        int places;

        try {

            places =
				Integer.parseInt(
				decimalPlacesPref
			);

        } catch (NumberFormatException e) {

            places = 10;
        }

        if (places < 0) {
            places = 0;
        }

        if (places > 20) {
            places = 20;
        }

        BigDecimal bd =
			new BigDecimal(
			Double.toString(value)
		);

        bd = bd.setScale(
			places,
			RoundingMode.HALF_UP
        );

        String plain =
			bd.toPlainString();

        if (plain.equals("-0")
			|| plain.equals("-0.0")
			|| plain.equals("-0.00")) {

            plain = "0";
        }

        if (useThousandsSeparator) {

            plain =
				applyThousandsSeparator(
				plain
			);
        }

        return plain;
    }

    /**
     * AUTO formatting.
     *
     * Keeps at most 15 significant digits.
     *
     * Scientific notation is used for:
     *
     * value >= 1,000,000,000,000
     *
     * or
     *
     * value < 0.000000000001
     */
    private static String formatAuto(
		double value,
		boolean useThousandsSeparator) {

        MathContext mc =
			new MathContext(
			MAX_SIGNIFICANT_DIGITS,
			RoundingMode.HALF_UP
		);

        BigDecimal bd =
			new BigDecimal(
			Double.toString(value)
		);

        bd = bd.round(mc);

        if (bd.compareTo(BigDecimal.ZERO) == 0) {
            return "0";
        }

        /*
         * Remove unnecessary zeros.
         */
        bd = bd.stripTrailingZeros();

        double abs =
			Math.abs(value);

        /*
         * Use scientific notation for very large
         * or very small values.
         */
        if (abs >= 1000000000000d
			|| abs < 0.000000000001d) {

            return formatScientific(bd);
        }

        /*
         * Normal decimal notation.
         */
        String plain =
			bd.toPlainString();

        /*
         * Remove trailing decimal point if any.
         */
        if (plain.endsWith(".")) {

            plain =
				plain.substring(
				0,
				plain.length() - 1
			);
        }

        /*
         * Negative zero protection.
         */
        if (plain.equals("-0")) {
            plain = "0";
        }

        if (useThousandsSeparator) {

            plain =
				applyThousandsSeparator(
				plain
			);
        }

        return plain;
    }

    /**
     * Converts BigDecimal to calculator-friendly
     * scientific notation.
     *
     * Example:
     *
     * 1234567890123
     *
     * becomes:
     *
     * 1.234567890123E12
     */
    private static String formatScientific(
		BigDecimal value) {

        String scientific =
			value.toString();

        int eIndex =
			scientific.indexOf('E');

        if (eIndex < 0) {
            return scientific;
        }

        String mantissa =
			scientific.substring(
			0,
			eIndex
		);

        String exponent =
			scientific.substring(
			eIndex + 1
		);

        /*
         * Remove unnecessary + sign.
         *
         * E+12 -> E12
         */
        if (exponent.startsWith("+")) {

            exponent =
				exponent.substring(1);
        }

        /*
         * Remove leading zeros from exponent.
         *
         * E012 -> E12
         * E-012 -> E-12
         */
        boolean negativeExponent =
			exponent.startsWith("-");

        String exponentDigits =
			negativeExponent
			? exponent.substring(1)
			: exponent;

        while (exponentDigits.length() > 1
			   && exponentDigits.startsWith("0")) {

            exponentDigits =
				exponentDigits.substring(1);
        }

        if (negativeExponent) {

            exponent =
				"-" + exponentDigits;

        } else {

            exponent =
				exponentDigits;
        }

        return mantissa + "E" + exponent;
    }

    /**
     * Adds comma separators to the integer part.
     *
     * Example:
     *
     * 1234567.89
     *
     * becomes:
     *
     * 1,234,567.89
     */
    private static String applyThousandsSeparator(
		String numberStr) {

        boolean negative =
			numberStr.startsWith("-");

        if (negative) {

            numberStr =
				numberStr.substring(1);
        }

        String integerPart;

        String decimalPart = "";

        int dotIndex =
			numberStr.indexOf('.');

        if (dotIndex >= 0) {

            integerPart =
				numberStr.substring(
				0,
				dotIndex
			);

            decimalPart =
				numberStr.substring(
				dotIndex
			);

        } else {

            integerPart = numberStr;
        }

        StringBuilder sb =
			new StringBuilder();

        int count = 0;

        for (int i = integerPart.length() - 1;
             i >= 0;
		i--) {

            sb.append(
				integerPart.charAt(i)
            );

            count++;

            if (count % 3 == 0
				&& i != 0) {

                sb.append(',');
            }
        }

        sb.reverse();

        return (negative ? "-" : "")
			+ sb.toString()
			+ decimalPart;
    }

    private static class Parser {

        private final String source;

        private int pos = 0;

        Parser(String source) {
            this.source = source;
        }

        boolean isAtEnd() {
            return pos >= source.length();
        }

        void skipWhitespace() {

            while (!isAtEnd()
				   && source.charAt(pos) == ' ') {

                pos++;
            }
        }

        char peek() {

            skipWhitespace();

            if (isAtEnd()) {
                return '\0';
            }

            return source.charAt(pos);
        }

        double parseExpression() {

            double value =
				parseTerm();

            while (true) {

                char c = peek();

                if (c == '+') {

                    pos++;

                    value +=
						parseTerm();

                } else if (c == '-') {

                    pos++;

                    value -=
						parseTerm();

                } else {

                    break;
                }
            }

            return value;
        }

        double parseTerm() {

            double value =
				parseUnary();

            while (true) {

                char c = peek();

                if (c == '*') {

                    pos++;

                    value *=
						parseUnary();

                } else if (c == '/') {

                    pos++;

                    double divisor =
						parseUnary();

                    if (divisor == 0d) {

                        throw new ArithmeticException(
							"Division by zero"
                        );
                    }

                    value /= divisor;

                } else {

                    break;
                }
            }

            return value;
        }

        double parseUnary() {

            char c = peek();

            if (c == '-') {

                pos++;

                return -parseUnary();
            }

            if (c == '+') {

                pos++;

                return parseUnary();
            }

            return parsePercent();
        }

        double parsePercent() {

            double value =
				parsePrimary();

            while (peek() == '%') {

                pos++;

                value =
					value / 100.0;
            }

            return value;
        }

        double parsePrimary() {

            char c = peek();

            if (c == '(') {

                pos++;

                double value =
					parseExpression();

                if (peek() != ')') {

                    throw new IllegalArgumentException(
						"Missing closing parenthesis"
                    );
                }

                pos++;

                return value;
            }

            if (c == '.'
				|| (c >= '0'
				&& c <= '9')) {

                return parseNumber();
            }

            throw new IllegalArgumentException(
				"Unexpected character"
            );
        }

        double parseNumber() {

            int start = pos;

            boolean seenDot = false;

            while (!isAtEnd()) {

                char c =
					source.charAt(pos);

                if (c >= '0'
					&& c <= '9') {

                    pos++;

                } else if (c == '.'
						   && !seenDot) {

                    seenDot = true;

                    pos++;

                } else {

                    break;
                }
            }

            String numStr =
				source.substring(
				start,
				pos
			);

            if (numStr.isEmpty()
				|| numStr.equals(".")) {

                throw new IllegalArgumentException(
					"Invalid number"
                );
            }

            try {

                return Double.parseDouble(
					numStr
                );

            } catch (NumberFormatException e) {

                throw new IllegalArgumentException(
					"Invalid number: " + numStr
                );
            }
        }
    }
}
