package com.tesnow.calculator;

import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.app.*;

public class MainActivity extends Activity implements View.OnClickListener {

    private static final int REQUEST_HISTORY = 1001;

    private TextView tvExpression;
    private TextView tvResult;

    private final StringBuilder expression = new StringBuilder();
    private boolean resultShown = false;
    private String appliedTheme;

    private PreferenceManager preferenceManager;
    private ToneGenerator toneGenerator;
    private Vibrator vibrator;

    private enum UnaryFunction {
        SQRT, SQUARE, RECIPROCAL
		}

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        ThemeUtils.applyTheme(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        appliedTheme = ThemeUtils.getSavedTheme(this);

        preferenceManager = new PreferenceManager(this);

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        try {
            toneGenerator =
				new ToneGenerator(AudioManager.STREAM_SYSTEM, 60);
        } catch (Exception e) {
            toneGenerator = null;
        }

        tvExpression = (TextView) findViewById(R.id.tvExpression);
        tvResult = (TextView) findViewById(R.id.tvResult);

        ImageButton btnMenu =
			(ImageButton) findViewById(R.id.btnMenu);

        btnMenu.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					showPopupMenu(v);
				}
			});

        int[] buttonIds = new int[]{
			R.id.btn0,
			R.id.btn1,
			R.id.btn2,
			R.id.btn3,
			R.id.btn4,
			R.id.btn5,
			R.id.btn6,
			R.id.btn7,
			R.id.btn8,
			R.id.btn9,

			R.id.btnDot,
			R.id.btnAdd,
			R.id.btnSub,
			R.id.btnMul,
			R.id.btnDiv,
			R.id.btnPercent,

			R.id.btnAC,
			R.id.btnDel,
			R.id.btnEquals,
			R.id.btnPlusMinus,

			R.id.btnSqrt,
			R.id.btnSquare,
			R.id.btnReciprocal,

			R.id.btnParenOpen,
			R.id.btnParenClose
        };

        for (int i = 0; i < buttonIds.length; i++) {

            Button b = (Button) findViewById(buttonIds[i]);

            if (b != null) {
                b.setOnClickListener(this);
            }
        }

        applyRuntimePreferences();
        updateDisplay();
    }

    @Override
    protected void onResume() {

        super.onResume();

        if (appliedTheme != null
			&& !appliedTheme.equals(ThemeUtils.getSavedTheme(this))) {

            recreate();
            return;
        }

        applyRuntimePreferences();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        if (toneGenerator != null) {
            toneGenerator.release();
            toneGenerator = null;
        }
    }

    @Override
    protected void onActivityResult(
		int requestCode,
		int resultCode,
		Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_HISTORY
			&& resultCode == RESULT_OK
			&& data != null) {

            String selected =
				data.getStringExtra(
				HistoryActivity.EXTRA_SELECTED_EXPRESSION
			);

            if (selected != null) {

                expression.setLength(0);
                expression.append(selected.replace(",", ""));

                resultShown = true;

                tvResult.setText(selected);

                updateDisplay();
            }
        }
    }

    private void applyRuntimePreferences() {

        if (preferenceManager.isKeepScreenOnEnabled()) {

            getWindow().addFlags(
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            );

        } else {

            getWindow().clearFlags(
				WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            );
        }

        boolean showExpression =
			preferenceManager.isShowExpressionEnabled();

        tvExpression.setVisibility(
			showExpression ? View.VISIBLE : View.INVISIBLE
        );
    }

    private void playFeedback() {

        if (preferenceManager.isButtonSoundEnabled()
			&& toneGenerator != null) {

            try {

                toneGenerator.startTone(
					ToneGenerator.TONE_PROP_BEEP,
					40
                );

            } catch (Exception ignored) {
            }
        }

        if (preferenceManager.isVibrationEnabled()
			&& vibrator != null
			&& vibrator.hasVibrator()) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

                vibrator.vibrate(
					VibrationEffect.createOneShot(
						20,
						VibrationEffect.DEFAULT_AMPLITUDE
					)
                );

            } else {

                vibrator.vibrate(20);
            }
        }
    }

    private void showPopupMenu(View anchor) {

        PopupMenu popup =
			new PopupMenu(this, anchor);

        popup.getMenuInflater().inflate(
			R.menu.top_menu,
			popup.getMenu()
        );

        popup.setOnMenuItemClickListener(
			new PopupMenu.OnMenuItemClickListener() {

				@Override
				public boolean onMenuItemClick(
					android.view.MenuItem item) {

					int id = item.getItemId();

					if (id == R.id.menu_settings) {

						startActivity(
							new Intent(
								MainActivity.this,
								SettingsActivity.class
							)
						);

						return true;

					} else if (id == R.id.menu_history) {

						startActivityForResult(
							new Intent(
								MainActivity.this,
								HistoryActivity.class
							),
							REQUEST_HISTORY
						);

						return true;

					} else if (id == R.id.menu_about) {

						startActivity(
							new Intent(
								MainActivity.this,
								AboutActivity.class
							)
						);

						return true;

					} else if (id == R.id.menu_exit) {

						showExitDialog();

						return true;
					}

					return false;
				}
			}
        );

        popup.show();
    }

    private void showExitDialog() {

        new AlertDialog.Builder(this)
			.setTitle(R.string.exit_dialog_title)
			.setMessage(R.string.exit_dialog_message)

			.setNegativeButton(
			R.string.action_cancel,
			new android.content.DialogInterface.OnClickListener() {

				@Override
				public void onClick(
					android.content.DialogInterface dialog,
					int which) {

					dialog.dismiss();
				}
			}
		)

			.setPositiveButton(
			R.string.action_exit,
			new android.content.DialogInterface.OnClickListener() {

				@Override
				public void onClick(
					android.content.DialogInterface dialog,
					int which) {

					dialog.dismiss();
					finishAffinity();
				}
			}
		)

			.setCancelable(true)
			.show();
    }

    @Override
    public void onClick(View v) {

        playFeedback();

        int id = v.getId();

        if (id == R.id.btnAC) {
            handleClear();
            return;
        }

        if (id == R.id.btnDel) {
            handleDelete();
            return;
        }

        if (id == R.id.btnEquals) {
            handleEquals();
            return;
        }

        if (id == R.id.btnPlusMinus) {
            toggleSign();
            return;
        }

        if (id == R.id.btnSqrt) {
            applyUnaryFunction(UnaryFunction.SQRT);
            return;
        }

        if (id == R.id.btnSquare) {
            applyUnaryFunction(UnaryFunction.SQUARE);
            return;
        }

        if (id == R.id.btnReciprocal) {
            applyUnaryFunction(UnaryFunction.RECIPROCAL);
            return;
        }

        if (id == R.id.btnDot) {
            appendDot();
            return;
        }

        if (id == R.id.btnParenOpen) {
            appendOpenParen();
            return;
        }

        if (id == R.id.btnParenClose) {
            appendCloseParen();
            return;
        }

        if (id == R.id.btnAdd) {
            appendBinaryOperator('+');
            return;
        }

        if (id == R.id.btnSub) {
            appendMinus();
            return;
        }

        if (id == R.id.btnMul) {
            appendBinaryOperator('\u00d7');
            return;
        }

        if (id == R.id.btnDiv) {
            appendBinaryOperator('\u00f7');
            return;
        }

        if (id == R.id.btnPercent) {
            appendPercent();
            return;
        }

        String digit = null;

        if (id == R.id.btn0) {
            digit = "0";
        } else if (id == R.id.btn1) {
            digit = "1";
        } else if (id == R.id.btn2) {
            digit = "2";
        } else if (id == R.id.btn3) {
            digit = "3";
        } else if (id == R.id.btn4) {
            digit = "4";
        } else if (id == R.id.btn5) {
            digit = "5";
        } else if (id == R.id.btn6) {
            digit = "6";
        } else if (id == R.id.btn7) {
            digit = "7";
        } else if (id == R.id.btn8) {
            digit = "8";
        } else if (id == R.id.btn9) {
            digit = "9";
        }

        if (digit != null) {
            appendDigit(digit);
        }
    }

    private char lastChar() {

        if (expression.length() == 0) {
            return '\0';
        }

        return expression.charAt(
			expression.length() - 1
        );
    }

    private boolean isBinaryOperatorChar(char c) {

        return c == '+'
			|| c == '-'
			|| c == '\u00d7'
			|| c == '\u00f7';
    }

    private String getLastNumberSegment() {

        int end = expression.length();
        int start = end;

        while (start > 0) {

            char c =
				expression.charAt(start - 1);

            if (Character.isDigit(c) || c == '.') {
                start--;
            } else {
                break;
            }
        }

        return expression.substring(start, end);
    }

    private void appendDigit(String digit) {

        if (resultShown) {

            expression.setLength(0);
            resultShown = false;
        }

        String lastNumberSegment =
			getLastNumberSegment();

        if (lastNumberSegment.equals("0")
			&& digit.equals("0")) {

            return;
        }

        if (lastNumberSegment.equals("0")) {

            expression.deleteCharAt(
				expression.length() - 1
            );
        }

        expression.append(digit);

        updateDisplay();
    }

    private void appendDot() {

        if (resultShown) {

            expression.setLength(0);
            resultShown = false;
        }

        String lastNumberSegment =
			getLastNumberSegment();

        if (lastNumberSegment.contains(".")) {
            return;
        }

        if (lastNumberSegment.isEmpty()) {

            expression.append("0.");

        } else {

            expression.append(".");
        }

        updateDisplay();
    }

    private void appendBinaryOperator(char op) {

        if (resultShown) {
            resultShown = false;
        }

        if (expression.length() == 0) {
            return;
        }

        char last = lastChar();

        if (last == '(') {
            return;
        }

        if (isBinaryOperatorChar(last)) {

            expression.deleteCharAt(
				expression.length() - 1
            );
        }

        expression.append(op);

        updateDisplay();
    }

    private void appendMinus() {

        if (resultShown) {
            resultShown = false;
        }

        expression.append('-');

        updateDisplay();
    }

    private void appendPercent() {

        if (resultShown) {
            resultShown = false;
        }

        char last = lastChar();

        if (last == '\0' || last == '%') {
            return;
        }

        if (Character.isDigit(last) || last == ')') {

            expression.append('%');

            updateDisplay();
        }
    }

    private void appendOpenParen() {

        if (resultShown) {

            expression.setLength(0);
            resultShown = false;
        }

        char last = lastChar();

        if (Character.isDigit(last)
			|| last == ')'
			|| last == '%') {

            expression.append('\u00d7');
            expression.append('(');

        } else {

            expression.append('(');
        }

        updateDisplay();
    }

    private void appendCloseParen() {

        int open = 0;
        int close = 0;

        for (int i = 0; i < expression.length(); i++) {

            char c = expression.charAt(i);

            if (c == '(') {
                open++;
            } else if (c == ')') {
                close++;
            }
        }

        if (open <= close) {
            return;
        }

        char last = lastChar();

        if (Character.isDigit(last)
			|| last == ')'
			|| last == '%') {

            expression.append(')');

            updateDisplay();
        }
    }

    private void toggleSign() {

        if (expression.length() == 0) {
            return;
        }

        int end = expression.length();
        int start = end;

        while (start > 0) {

            char c =
				expression.charAt(start - 1);

            if (Character.isDigit(c) || c == '.') {
                start--;
            } else {
                break;
            }
        }

        if (start == end) {
            return;
        }

        if (start > 0
			&& expression.charAt(start - 1) == '-') {

            int beforeMinus = start - 1;

            boolean isUnary =
				beforeMinus == 0
				|| isBinaryOperatorChar(
				expression.charAt(beforeMinus - 1)
			)
				|| expression.charAt(beforeMinus - 1) == '(';

            if (isUnary) {

                expression.deleteCharAt(beforeMinus);

                updateDisplay();

                return;
            }
        }

        expression.insert(start, '-');

        updateDisplay();
    }

    private void handleClear() {

        expression.setLength(0);
        resultShown = false;

        updateDisplay();
    }

    private void handleDelete() {

        if (resultShown) {

            handleClear();
            return;
        }

        if (expression.length() > 0) {

            expression.deleteCharAt(
				expression.length() - 1
            );
        }

        updateDisplay();
    }

    private void handleEquals() {

        if (expression.length() == 0) {
            return;
        }

        String originalExpression =
			expression.toString();

        try {

            double value =
				ExpressionEvaluator.evaluate(
				originalExpression
			);

            String formatted =
				ExpressionEvaluator.formatResult(
				value,
				preferenceManager.getDecimalPlaces(),
				preferenceManager
				.isThousandsSeparatorEnabled()
			);

            tvResult.setText(formatted);

            if (preferenceManager.isSaveHistoryEnabled()) {

                HistoryManager.addEntry(
					this,
					originalExpression,
					formatted
                );
            }

            expression.setLength(0);

            expression.append(
				formatted.replace(",", "")
            );

            resultShown = true;

        } catch (Exception e) {

            tvResult.setText(
				R.string.error_text
            );
        }
    }

    private void applyUnaryFunction(
		UnaryFunction function) {

        String source =
			expression.length() == 0
			? "0"
			: expression.toString();

        try {

            double base =
				ExpressionEvaluator.evaluate(
				source
			);

            double result;
            String prefix;

            switch (function) {

                case SQRT:

                    if (base < 0) {
                        throw new ArithmeticException(
							"Invalid input"
                        );
                    }

                    result = Math.sqrt(base);
                    prefix = "\u221a";

                    break;

                case SQUARE:

                    result = base * base;
                    prefix = "sqr";

                    break;

                case RECIPROCAL:

                    if (base == 0) {

                        throw new ArithmeticException(
							"Division by zero"
                        );
                    }

                    result = 1.0 / base;
                    prefix = "1/x";

                    break;

                default:
                    return;
            }

            String formatted =
				ExpressionEvaluator.formatResult(
				result,
				preferenceManager.getDecimalPlaces(),
				preferenceManager
				.isThousandsSeparatorEnabled()
			);

            String displayExpression =
				prefix + "(" + source + ")";

            tvExpression.setText(
				displayExpression
            );

            tvResult.setText(formatted);

            if (preferenceManager.isSaveHistoryEnabled()) {

                HistoryManager.addEntry(
					this,
					displayExpression,
					formatted
                );
            }

            expression.setLength(0);

            expression.append(
				formatted.replace(",", "")
            );

            resultShown = true;

        } catch (Exception e) {

            tvResult.setText(
				R.string.error_text
            );
        }
    }

    private void updateDisplay() {

        tvExpression.setText(
			expression.toString()
        );

        if (!resultShown) {

            tvResult.setText(
				expression.length() == 0
				? getString(R.string.default_display)
				: ""
            );
        }
    }
}
